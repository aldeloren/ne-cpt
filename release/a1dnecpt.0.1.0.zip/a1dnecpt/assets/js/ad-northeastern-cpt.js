/*! A1D Northeastern CPT - v0.1.0
 * https://a1d.co/
 * Copyright (c) 2015; * Licensed GPLv2+ */
( function( window, undefined ) {
	'use strict';


} )( this );
